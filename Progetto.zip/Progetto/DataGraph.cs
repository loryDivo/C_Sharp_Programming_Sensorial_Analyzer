﻿using System;

public class DataGraph
{
	public DataGraph()
	{
	}
}
