﻿using System;

public class EventLog
{
	public EventLog()
	{
	}
}
