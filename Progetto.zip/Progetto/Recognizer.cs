﻿using System;

public class Recognizer { 
	public Recognizer()
	{
	}
}
