﻿using System;

public class UtilityFunctions
{
	public UtilityFunctions()
	{
	}
}
