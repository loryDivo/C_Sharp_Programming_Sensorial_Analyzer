﻿using System;

public class VisualThread
{
	public VisualThread()
	{
	}
}
